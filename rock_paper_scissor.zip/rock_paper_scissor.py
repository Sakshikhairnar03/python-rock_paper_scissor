import tkinter as tk
import random

# Initialize scores
user_score = 0
computer_score = 0

# Function to update the score
def update_score(result):
    global user_score, computer_score
    if result == "User wins":
        user_score += 1
    elif result == "Computer wins":
        computer_score += 1
    user_score_label.config(text=f"User: {user_score}")
    computer_score_label.config(text=f"Computer: {computer_score}")

# Function to play the game
def play_game(user_choice):
    choices = ["Rock", "Paper", "Scissors"]
    computer_choice = random.choice(choices)

    # Determine the winner
    if user_choice == computer_choice:
        result = "It's a tie"
    elif (
        (user_choice == "Rock" and computer_choice == "Scissors")
        or (user_choice == "Scissors" and computer_choice == "Paper")
        or (user_choice == "Paper" and computer_choice == "Rock")
    ):
        result = "User wins"
    else:
        result = "Computer wins"

    # Update the result label and score
    result_label.config(text=f"User: {user_choice} | Computer: {computer_choice} | {result}")
    update_score(result)

# Create the main window
root = tk.Tk()
root.title("Rock, Paper, Scissors!!!!  Game Let's Play!!!!!!!!!")
root.geometry("800x500+50+50")
f1=("Simsun", 30, "bold")
bg=("lightblue")
bg2=("yellow")
bg3=("lavender")
root['background'] = "black"
# Create labels for user and computer scores
user_score_label = tk.Label(root, text=f"User: {user_score}",font=f1,background="yellow")
computer_score_label = tk.Label(root, text=f"Computer: {computer_score}",font=f1,background="yellow")
user_score_label.pack()
computer_score_label.pack()

# Create buttons for rock, paper, and scissors
rock_button = tk.Button(root, text="Rock",font=f1,width=15,background="lightblue", command=lambda: play_game("Rock"))
paper_button = tk.Button(root, text="Paper",font=f1,width=15, background="lightblue", command=lambda: play_game("Paper"))
scissors_button = tk.Button(root, text="Scissors",font=f1,width=15,background="lightblue",  command=lambda: play_game("Scissors"))

rock_button.pack()
paper_button.pack()
scissors_button.pack()

# Create a label for displaying the game result
result_label = tk.Label(root, text="", font=("Malgun Gothic", 22),background="lavender")
result_label.pack()

# Start the main loop
root.mainloop()
